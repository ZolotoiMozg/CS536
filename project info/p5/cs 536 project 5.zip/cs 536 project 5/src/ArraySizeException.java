public class ArraySizeException extends Exception {} 
